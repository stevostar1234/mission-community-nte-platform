# NTE Stripe: implementation and client account handover

Prepared 11 September 2026 for the project owner. This is an internal explanation and proposed handover sequence, not approval to change accounts, send emails, collect payments or deploy production.

The current integration creates Stripe Payment Links from Salesforce bookings and sends them in the provisional reservation email. Payment confirmation in Salesforce remains a staff action. The released implementation supports any valid booking recipient, ordinary form references, and explicit test/live environments. Proposal 20 removes the blanket live-mode rejection. MMUAT remains connected to the owner-controlled Stripe sandbox; the client account and production still require configuration, qualification and an authorised release. See [the latest readiness results](audit/NTE_STRIPE_LIVE_READINESS_2026-09-11.md).

## What to request from the client now

Request **team invitations to our own work email**, using our own Stripe login and two-factor authentication. There is no need to share the client's password or create a separate shared login for each environment.

1. **Arrange live and sandbox access together now.** One live-account invitation can assign **Developer + Sandbox Administrator**: Developer supplies live integration/debugging access, and Sandbox Administrator supplies access to all that account's sandboxes. If access should cover only NTE's private sandbox, grant Developer in live and add the developer directly to that sandbox at the same time. Live Developer alone does not automatically grant access to every private sandbox. There is no requirement to wait until sandbox testing is finished before arranging live access. [Sandbox access](https://docs.stripe.com/sandboxes/dashboard/manage-access).
2. **Choose Administrator if the brief includes administering the whole setup.** Developer covers keys, logs, events, payments/refunds/disputes and most product settings, including payment and fraud configuration. It cannot invite/edit team members or change bank accounts/payout schedules. If we must also add Kate and administer team/finance settings while the client contact is away, request **Administrator** for setup, then review/reduce access after handover. Administrator inherits sandbox access; account ownership is unnecessary. The client retains ownership and completes any identity/bank verification requiring their information. [Stripe roles](https://docs.stripe.com/get-started/account/teams/roles).
3. **Dedicated NTE test and live API credentials**, created securely once the invitations are accepted. Use separate restricted keys with only the integration's required permissions, qualified in the client sandbox. Populate the matching Salesforce External Credential; do not put keys in an email, document or public form. The client does not need to send an existing general-purpose key. No publishable key or webhook signing secret is required for the current hosted Payment Links/manual-confirmation route. [Restricted keys](https://docs.stripe.com/keys/restricted-api-keys).
4. **Confirmation of the intended merchant, payment settings and live-account readiness.** Confirm the VAT treatment and worked totals, payment methods, receipt/notification choices and merchant/support wording. The merchant must have live payments enabled and its payout bank/verification requirements completed inside Stripe. This does not require sending banking or identity documents to us. [Account activation](https://docs.stripe.com/get-started/account/set-up).
5. **Authorised production Salesforce deployment/configuration access and the agreed production form destination.** Stripe access alone does not deploy the NTE integration. Sandbox acceptance and live activation remain distinct steps.

Prefer **Copy your account** when creating the client sandbox, then compare settings explicitly. Stripe does not copy Radar settings, and copied settings do not stay synchronised. Our existing highest-risk test proves the owner-controlled sandbox's behavior, not the client's fraud configuration. [Sandbox settings](https://docs.stripe.com/sandboxes/dashboard/sandbox-settings).

After access arrives, connect MMUAT to the client's sandbox and qualify its settings. The explicit live code path is now implemented and validated with mocked live responses. Populate the separate live credential, bind the approved production org/merchant, select live mode, and enable collection for the authorised launch. Existing test links remain test links; production creates new live resources. A key swap alone is still insufficient because merchant, org and mode must agree, but no further code edit is needed merely to allow live payments.

Suggested access request:

> Please invite my work email to the Stripe account that will receive NTE payments, with access to both live and an NTE sandbox now. As we will be configuring the integration and team notifications, Administrator access for setup would cover the work; you retain account ownership. Alternatively, Developer plus Sandbox Administrator covers integration and debugging if someone on your team can manage team invitations and bank/payout settings. If creating the sandbox, please use “Copy your account.” We will use our own login and two-factor authentication. Please confirm that the intended merchant is enabled for live payments and complete any outstanding identity/bank verification inside Stripe. We can create the dedicated NTE credentials after access is granted; please do not email passwords or API keys.

## Further failure tests worth prioritising

The [focused demonstration](audit/NTE_STRIPE_FAILURE_DEMO_2026-09-11.md) already covers issuer decline, highest-risk blocking, failed/successful 3DS, an open dispute and a full refund. Both used-link closure and failed-payment retryability were verified. New descriptions now use **NTE booking · [reference]**; older requests retain their original saved wording.

The focused follow-up now proves cancelled authentication collected nothing, the same checkout recovered to exactly one authenticated payment, the used link closed, and an Opportunity with a Close Date three months in the past remained usable. The actual provisional email contained the correct reference, £799 net, £159.80 VAT, £958.80 total and test link. Mobile-width layout was inspected. Apple Pay was displayed; a real device/wallet transaction was not tested.

A temporary native Stripe Workflow also passed both branches: `payment_intent.succeeded` with `nte_charge_kind=Booking` sent one email to the owner's address; a generic successful Stripe fixture did not send one. The Workflow is now inactive, with both runs retained. This supports a simple NTE-only success alert for Kate, subject to availability, any plan terms, and her team membership in the client's account. The demonstrated alert contains a short note, not a detailed transaction summary; configure useful reference/amount fields if the client's Workflow editor supports them. Notification filtering does not restrict a user's Stripe Dashboard record visibility. Refund/dispute alerts need their own event/condition qualification; the payment-success test does not prove those routes.

The full Salesforce package passes **314 local tests**. Focused automated coverage includes live-mode responses, wrong account/mode, unavailable live charges, invalid/revoked/insufficient credentials, rate limiting, timeouts and malformed responses, stable request/link reuse, failed-email recovery, past dates and Closed Won eligibility. These are controlled API simulations where stated; the active sandbox key was not deliberately revoked.

Repeat representative exhibitor and partner journeys in the **client's** sandbox using its actual restricted key and agreed settings. Remaining account-dependent checks are its Radar/3DS configuration, receipts and notification categories, restricted-key permissions, supported wallets/devices and any extra payment methods. An actual real-money card test was not performed. See [exact outcomes and boundaries](audit/NTE_STRIPE_LIVE_READINESS_2026-09-11.md).

## How a booking travels through the system

| Step | What happens | Who does it |
| --- | --- | --- |
| 1. Application | The applicant chooses Stripe and submits the exhibitor or partner/sponsor form. Salesforce receives an application Lead. Submission itself creates neither a Stripe link nor a charge. | Applicant and existing Web-to-Lead processing |
| 2. Review and conversion | Staff review the application and convert it into its booking Opportunity. The conversion's explicit Opportunity ID identifies the booking used by the payment process. | NTE staff |
| 3. Save the charge | For an eligible booking, Salesforce validates the saved pricing and Primary Contact and saves a related payment request containing the exact net amount, tax rate, payable total, recipient, booking reference and Stripe account. | Salesforce |
| 4. Create the payment link | A background job runs after the Salesforce transaction commits. It verifies the Stripe account and configured test/live mode, creates a fixed Price and Payment Link, and reads them back to check the amount, currency, identity and restrictions. | Salesforce calling Stripe |
| 5. Send the reservation email | Salesforce saves the verified URL, checks that the booking has not changed, and sends the itemised provisional email with its Stripe button and preparation links to the booking's Primary Contact. | Salesforce |
| 6. Pay | The applicant opens Stripe's hosted checkout and pays there. Card entry takes place on Stripe, not on an NTE form or in Salesforce. | Applicant and Stripe |
| 7. Verify | Staff find the successful payment in the correct Stripe account, match the booking reference and saved payable amount/currency, and check its current refund/dispute status. A checkout screenshot or opened link is insufficient. | NTE finance/operations |
| 8. Confirm the space | Staff use **Booking payment received** in NTE Management. Salesforce records the milestone and requests the existing single booking-confirmation email. Repeating an already completed action must not produce a second accepted confirmation. | NTE staff and Salesforce |

There is no automatic Stripe-to-Salesforce payment notification receiver in this release. A successful Stripe payment therefore does not, by itself, mark the Salesforce booking paid. The manual action does not independently ask Stripe whether payment succeeded: the staff verification is essential.

The booking confirmation does not complete staff, logo or vehicle information, send the final pack, or automatically establish that every event preparation requirement is complete.

## Money, documents and recipients

Salesforce's saved booking pricing is the source of the amount. Applicable complimentary entitlements and discounts feed that saved pricing before Stripe receives a charge. A completely free booking does not need a Stripe request; a complimentary space can still have chargeable extras.

The current test configuration adds a single **20%** rate to the net booking total. That is a provisional test choice, not the client's approved VAT policy. For arithmetic illustration only, a £100 net booking becomes £20 tax and £120 payable. Stripe receives 12,000 pence as one fixed GBP Price. The reservation email itemises the allocation, net amount, VAT and gross amount; Stripe checkout currently receives one booking charge rather than a separate product for every space, socket and staff place. Reconciliation must compare Stripe with the saved gross payable amount, rather than the net booking total.

**Stripe automatic tax is disabled.** The amount has already been calculated in Salesforce. If the client confirms that no VAT should be added, a zero rate is technically supported for new requests, with matching form/email wording and worked examples to verify. Different treatment by item, organisation or package would require a richer calculation than the current single rate. An existing issued request must be reconciled before changing its amount or tax treatment.

**Stripe invoice creation is disabled.** The combined email can record the existing invoice/link-provided milestone and, when a quote was requested, quote-provided. This does not create a numbered formal invoice or prove receipt of a purchase order. The client's separate finance-document process still needs to be agreed.

Salesforce booking emails use the booking's **Primary Contact**, with no automatic finance-contact copy. The payer can supply another email address in Stripe. A Stripe payment receipt and a Salesforce space-confirmation email serve different purposes. Receipt settings belong to the client's Stripe account; current Stripe guidance uses manual receipt sending for test payments. [Stripe receipts](https://docs.stripe.com/receipts).

The requested charge currency is GBP. Payment Links can offer local-currency payment through Adaptive Pricing, so GBP-only customer presentation must not be promised without checking the client's requirements and checkout behavior. A strict GBP-only requirement could affect the selected integration approach. The present URL validator also accepts only `buy.stripe.com`, so a client-specific Stripe checkout domain would require an explicit validator change. [Payment Link customisation](https://docs.stripe.com/payment-links/customize).

Money belongs to the Stripe merchant account identified by its credential. The client's payout bank account and payout schedule are configured inside Stripe; the integration does not pass a bank destination with each booking. A successful customer payment and a payout reaching the bank are separate events. Finance must reconcile fees and payouts separately from the customer's gross booking payment. [Stripe payouts](https://docs.stripe.com/payouts).

## Existing controls and current limits

The current released configuration is:

| Setting | Current value |
| --- | --- |
| Salesforce environment | MMUAT sandbox, `00DAd00000A95VlMAJ` |
| Stripe environment | Owner-controlled test sandbox, `acct_1UD8GwBcW1MkMYQ1`, named **client test stripe sandbox** |
| Booking reference | No prefix filter; normal generated references are accepted |
| Primary Contact email | Any valid email; the optional recipient filter is blank |
| Currency and test tax | GBP; 20% single rate |
| Secure connection | `NTE_Stripe_Test` while Live Payments is false; separate `NTE_Stripe_Live` definitions are deployed and not populated by this release |
| Environment selection | Default config `Live_Mode__c=false`; each payment request snapshots its own mode |
| Secret location | External Credential principal `NTEApplication`, authentication parameter `ApiKey` |
| API version sent by the code | `2026-08-26.dahlia` |

On 11 September the owner explicitly approved removing the active reference and email filters. Two fresh ordinary browser applications were converted and received their correct test payment links at the owner’s two email domains. Selecting Stripe on a payable ordinary form is sufficient for link creation after valid conversion into a new booking with a usable Primary Contact; submission alone creates no link. [Release and remaining sandbox differences](audit/NTE_STRIPE_DEMO_READINESS_2026-09-11.md).

The integration fixes quantity at one, requests card payments, disables promotion codes and adjustable quantities, and sets a limit of one completed checkout per link. It does not implement deposits, instalments or recurring charges. Card wallets depend on Stripe, account and browser availability; additional payment methods need separate qualification.

Each booking charge has a stable operation key and saved Stripe resource IDs. Retrying an interrupted creation uses the same identity and payload; retrying a failed email reuses the saved link. A changed price, recipient or account configuration causes a review hold rather than silent replacement. Creation with an unknown outcome older than 23 hours is held for reconciliation, because Stripe's idempotency retention must not be treated as permanent. These controls reduce duplicate and stale requests; they are not a substitute for reconciliation. [Stripe idempotent requests](https://docs.stripe.com/api/idempotent_requests).

The secret is supplied server-side through Salesforce's credential store. It is absent from public forms and source-controlled configuration. Salesforce metadata deployment does not carry the stored secret into the destination org: the destination principal must be populated securely. [Salesforce external credential setup](https://developer.salesforce.com/docs/platform/named-credentials/guide/nc-populate-external-credentials.html).

## Once access to the client's Stripe sandbox arrives

1. **Client: identify the intended merchant and invite the developer.** Use a dedicated sandbox belonging to the account that will receive NTE payments. Invite through Stripe's team settings rather than sharing a login. Access can be limited to that sandbox. [Sandbox access](https://docs.stripe.com/sandboxes/dashboard/manage-access).

2. **Client and developer: compare the sandbox with the intended live account.** Prefer a sandbox created using **Copy your account**. Record the sandbox and live account IDs separately. Compare relevant business, payment, currency, checkout and receipt settings: copied settings do not remain synchronised, and some settings are excluded. [Sandbox settings](https://docs.stripe.com/sandboxes/dashboard/sandbox-settings).

3. **Client: confirm the commercial instructions.** Approve worked net/tax/gross examples, full-payment timing, supported payment methods, payer receipts, formal invoice ownership, purchase-order handling, deadlines and cancellation/refund responsibility. The existing [client questionnaire](NTE_STRIPE_CLIENT_CONFIGURATION_QUESTIONS.md) captures these decisions; it is not itself an instruction to implement every optional feature.

4. **Developer: create and qualify a restricted test API key.** The code reads account and balance information, creates/reads Prices with an inline Product, and creates/reads Payment Links and their line items. Map those operations to the client's available restricted-key permissions and verify the minimum necessary set in sandbox. No publishable browser key is needed for this hosted Payment Links architecture. [Restricted API keys](https://docs.stripe.com/keys/restricted-api-keys).

5. **Developer: plan the account switch in MMUAT.** Pause Stripe application conversions/email release as well as new Stripe request processing, identify queued or unresolved requests from the current owner sandbox, and settle or isolate them before changing the connection. Old requests and links belong to their original Stripe account; do not relabel them as client requests or replay them under the new key. Turning the Salesforce enable flag off does not deactivate already-issued links in Stripe. It is also not a general email stop: a new booking outside the enabled Stripe scope can take the ordinary provisional-email path without a Stripe button.

6. **Developer/admin: configure the secure Salesforce connection.** Under **Setup → Named Credentials → External Credentials**, use `NTE_Stripe_Test`, principal `NTEApplication`, and securely populate the `ApiKey` authentication parameter. Under **Custom Metadata Types → NTE Stripe Config → Manage Records → Default**, set **Live Payments=false**, the expected client sandbox account, exact Salesforce sandbox ID and approved test rate, with both optional recipient/reference filters left blank for representative end-to-end testing. Keep processing disabled until the connection checks pass. Secret values belong in the encrypted principal, never in ordinary metadata, chat, email or Git. [Stripe key handling](https://docs.stripe.com/keys).

7. **Developer: verify identity and operator access before enabling selected cases.** Read back the Stripe account and test-mode balance through the Salesforce Named Credential. Check the account's country/currency and relevant capabilities. Test as the actual NTE users, including a Standard User, with **NTE Management Access**. Salesforce group membership supplies application/credential-use access; separate Stripe Dashboard access is needed for anyone verifying payments.

8. **Developer: verify representative recipient and reference settings.** The active email/reference restrictions were removed in the 11 September release. Keep both optional fields blank when connecting the client sandbox so ordinary forms and client tester addresses continue working. Verify the actual Primary Contact after conversion and use a new booking Opportunity. Expected account/org and selected environment checks remain mandatory.

9. **Client and developer: run fresh end-to-end cases.** Exercise an exhibitor and partner/sponsor from actual form submission through conversion, link creation, email, test checkout, staff verification and Salesforce confirmation. Include payable extras and applicable discounts, free bookings without payment requests, existing Account/Contact reuse with a new booking, and the separate bank-transfer route. Use Stripe's test payment methods; no money moves in a sandbox. [Stripe sandboxes](https://docs.stripe.com/sandboxes).

10. **Developer and client testers: exercise failure and retry cases.** Cover declined cards, additional card authentication, interrupted creation, email failure, repeated actions, changed totals/contacts, revoked or insufficient key access, wrong-account/mode rejection, used/inactive links, and cancelled or already-paid bookings. Check exact amounts and references in Salesforce, Stripe and actual received emails. Do not interpret a ready link as a paid booking. Record the results and get client acceptance of both the journey and daily staff process.

## Before connecting the live Stripe account

1. **Client: complete merchant activation and finance setup.** Verify the legal entity, live account ID, account activation requirements, payout bank and schedule, branding, statement descriptor, support contact, policies, and chosen customer/internal Stripe notifications. The client completes identity and bank verification inside Stripe. [Stripe accounts](https://docs.stripe.com/get-started/account); [account checklist](https://docs.stripe.com/get-started/account/checklist).

2. **Developer: use the released explicit live mode.** Proposal 20 is implemented in source and MMUAT: choose `Live_Mode__c=true` in the production config, use the separate `NTE_Stripe_Live` Named/External Credential, and set the exact production Salesforce org and client live merchant. The code verifies account identity, `livemode`, live `charges_enabled`, resource amount/currency/metadata and the matching Stripe-hosted URL. Each request retains its own mode; a config switch cannot silently relabel an old test request. Five deployed Apex bodies match source; 51 affected and 314 full local tests passed. This is implementation evidence, not proof of an unconnected client's live account.

3. **Client and developer: settle the remaining affected workflow decisions.** Establish a new booking for each application while allowing reuse of the organisation/contact; decide how to handle an old provisional-email retry after payment; define revised-price, cancellation and late-payment handling. Automated staff top-up links need their own approved implementation if wanted. These items must be resolved or kept outside the activated collection route; they are not already completed features.

4. **Developer: qualify the production candidate in sandbox.** Test the approved business rules, environment mismatch rejection and actual user permissions. Run the applicable local checks, Salesforce tests and full package validation. Keep public form/email previews aligned with approved changes. Existing MMUAT test passes do not replace this client-specific qualification.

5. **Developer/admin: prepare production Salesforce with Stripe disabled.** Deploy the reviewed package to the authorised production org. Configure its org/account identifiers, secure live credential principal and existing **NTE Management Access** group, whose **NTE Stripe Payment Operator** component now grants use of both environment principals. Populate a separate live restricted key with the permissions proven in sandbox. Test keys, sandbox IDs, old payment requests and old Stripe links must not be copied as live payment resources. [Stripe go-live guidance](https://docs.stripe.com/get-started/checklist/go-live).

6. **Developer and client: complete the surrounding launch configuration.** Confirm production Web-to-Lead organisation/endpoint settings, form and preparation URLs, verified Salesforce sender and deliverability, templates, approved amounts, NTE permissions and staff ownership. Keep the Salesforce group simple for onboarding; production credential access must be part of its verified production configuration. Read-only connection checks establish the intended live merchant and mode before allowing creation.

7. **Client: approve activation; developer: enable the agreed scope.** Leave MMUAT connected to the client's test sandbox and production connected only to live Stripe. Record the launch configuration and recovery instructions. The current explanation is not production deployment or payment authorisation.

8. **NTE staff and developer: observe the first genuine live bookings.** Follow the normal customer journey and reconcile the successful payment, Salesforce confirmation, receipt and subsequent payout. All simulated card testing belongs in sandbox; do not manufacture a live charge solely as a test. [Stripe testing guidance](https://docs.stripe.com/testing).

9. **Client operations: own the daily process.** Assign a person and cover for reviewing Stripe payments and Salesforce pending/failed requests, recording verified payments, and handling refunds/disputes. Pause new request creation and the affected conversion/email-release work during an incident; close affected outstanding links in Stripe separately when needed. Rotate credentials through a controlled change and repeat the connection checks.

## Close Date, revised bookings and cancellations

**Close Date is an expected date, not a timer.** The native converted Opportunities currently default to 30 September 2026, the end of the current fiscal quarter. Passing that date does not set Closed Won or Closed Lost. No active NTE flow, Opportunity workflow rule, Apex trigger or scheduled closure job was found doing that. A new test booking with `CloseDate=2026-06-11` stayed in Qualification and completed payment on 11 September. [Salesforce Opportunity fields](https://help.salesforce.com/s/articleView?id=sales.opp_fields.htm&language=en_US).

Closed Won remains included in active NTE views and eligible workflows, subject to the other booking checks. Closed Lost is excluded from active booking views and blocks new payment-request emails. Neither stage change issues a Stripe refund or closes an existing Stripe link. Stripe payment success, refunds and disputes do not update Salesforce automatically under the chosen manual model. Payment, stage and preparation are separate facts. The current finance reports exclude Closed Lost bookings and do not provide a separate refund ledger; retain the refund reference on the booking and reconcile refund amounts in Stripe.

For an agreed booking change, manual bank transfer is a reasonable fallback. Keep the revised total, amount already received, balance and payment reference clear. **If a saved Stripe request exists and the booking's net amount changes, the current automatic confirmation email refuses to render because the saved and current totals differ.** Recording payment is still possible; an agreed manual confirmation or a separately approved reconciliation change is needed. Do not rewrite the old saved payment request solely to suppress this check.

For a cancellation, refund through Stripe as agreed with the client and mark the booking Closed Lost, preserving the original payment and refund history. Wait for the refund outcome before describing it as completed. Partial refunds do not necessarily mean the booking is cancelled. Leaving an unused old link active allows an accidental late payment, so the recommendation is to deactivate superseded or cancelled unpaid links manually. This does not add an automatic cancellation feature.

A Stripe Price's amount cannot be edited in place. The inspected active NTE link also has **More options → Edit** disabled in Stripe's Dashboard. Changing a price requires a new Price; existing booking requests and emailed links do not track later Salesforce totals. Stripe allows editing some other link settings; this does not make these issued NTE amounts adjustable. Do not treat a Dashboard edit as an NTE reconciliation mechanism. Prefer a clearly identified replacement request or the agreed bank-transfer route, with the old link closed and original history retained. [Stripe Prices](https://docs.stripe.com/products-prices/manage-prices).

**Do not make a nominal live charge solely as a test.** Stripe's current testing guidance prohibits testing live mode with real payment details. Use its sandbox cards for simulations, read-only live account/credential checks and checkout inspection for launch readiness, then reconcile the first genuine authorised booking. [Stripe testing guidance](https://docs.stripe.com/testing).

## Outstanding decisions and implementation boundaries

| Item | Current position | Before the affected live route |
| --- | --- | --- |
| VAT and gross payable amount | One provisional 20% test rate | Client-approved worked examples and matching wording/calculations |
| New booking on conversion — P03 | Payment code uses the exact converted Opportunity, but native conversion still permits an existing or no Opportunity; it can overwrite an earlier booking before Stripe holds it | Agree and qualify the conversion safeguard; the payment checks do not solve the underlying conversion risk |
| Provisional retry after payment — P01 | Payment confirmation can proceed independently; the Stripe route blocks a new payment email for an already-paid booking, but the recovery outcome for the old failed provisional remains undecided | Choose suppression or appropriate replacement content without undoing payment |
| Price changes/cancellation | Owner proposes manual bank transfer for changed totals and Dashboard refunds/Closed Lost for cancellations; existing links stay unchanged | Deactivate superseded unpaid links. A changed net total also blocks the automatic confirmation email until reconciled; use an agreed manual confirmation or separately approve reconciliation support |
| Staff top-up | Existing Salesforce finance milestones; automatic additional Stripe link not wired into this release | Separate approval and qualification if automated collection is wanted |
| Receipts, formal invoices and PO timing | Manual confirmation chosen; Stripe Invoicing excluded | Client assigns finance-document and notification ownership |
| Production support | Explicit test/live path released and automated live contracts passed; MMUAT still uses test mode | Client credentials, exact org/account/mode, merchant activation, agreed settings, production deployment and client qualification |

## Evidence and implementation map

This explanation is based on the source and latest retained release evidence, plus primary documentation checked on 11 September 2026. The later demo release verifies two fresh form-to-link/email journeys, without claiming client-account access or repeating historical payments. See the linked 11 September qualification.

- [Payment coordinator](force-app/main/default/classes/NTEStripeBookingService.cls): selection, charge snapshot, background work, account/booking rechecks, retry handling and delivery milestones.
- [Stripe HTTP client](force-app/main/default/classes/NTEStripeClient.cls): API version, credential selection, Price/Link creation and verification, and environment/account checks.
- [Booking email service](force-app/main/default/classes/NTEExhibitorApprovalEmailService.cls): itemised totals, Stripe button, Primary Contact rendering and email readiness.
- [Current non-secret configuration](force-app/main/default/customMetadata/NTE_Stripe_Config.Default.md-meta.xml), [Named Credential](force-app/main/default/namedCredentials/NTE_Stripe_Test.namedCredential-meta.xml), [External Credential definition](force-app/main/default/externalCredentials/NTE_Stripe_Test.externalCredential-meta.xml).
- [Read-only account preflight](scripts/stripe-preflight.py): checks account identity and the configured test/live mode; it does not prove Price creation, Payment Links or email delivery.
- [Retained Stripe journey evidence](audit/NTE_STRIPE_SANDBOX_IMPLEMENTATION_2026-09-08.md): earlier exhibitor and partner test payments, each followed by manual Salesforce confirmation. Historical prices and records are not a current catalogue or instruction to replay them.
- [Latest release evidence](audit/NTE_STRIPE_LIVE_READINESS_2026-09-11.md): full package validation passed 314 local Salesforce tests, with 474 component identities and 538 canonical source/manifest hashes reconciled. Package tests are not 314 real checkout journeys.
- [Desired workflow](NTE_DESIRED_WORKFLOW.md), [open decisions](audit/NTE_STRESS_TEST_AND_IMPROVEMENTS_2026-09-07.md), [production package workflow](PRODUCTION_PACKAGE_SYNC.md).

The original handover was planning only. This revision records the later, explicitly authorised proposal 20 implementation and sandbox tests; it does not authorise a client-account switch or production deployment.
