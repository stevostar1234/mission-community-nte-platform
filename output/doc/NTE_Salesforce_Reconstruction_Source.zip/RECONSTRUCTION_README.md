# NTE Salesforce reconstruction source

This archive accompanies the 12 September 2026 NTE Salesforce Operations and Reconstruction Manual. Start with that manual's workflow, then follow Reconstruction and administration and its exact field, form, Flow, Apex and configuration references.

## Rebuild the supplied candidate

1. Extract the archive into an empty directory. Verify SHA256SUMS.txt before making changes.
2. Run `node scripts/build-metadata.js` from the extracted root. This regenerates the supplied metadata and email examples from their maintained generators.
3. Run the project-specific local checks listed in the manual. The recorded metadata-reports test harness failure is described in documentation/PROJECT_DOCUMENTATION_ISSUES.md.
4. Apply destination configuration and a target-preserving shared-picklist overlay as described in the manual. The source targets MMUAT; public Salesforce field IDs are organisation-specific. Supply client-owned final-pack, logo, sender and merchant settings at the documented points.
5. Validate the exact candidate against its authorised destination before release. Completed MMUAT fixtures and accepted sends must not be replayed as setup steps.

The archive is source, not an installed Salesforce org or a data migration. API credentials, authentication caches, raw native exports, Git internals and operating-system files are excluded. The configuration examples contain no API keys. Historical audit narratives are retained for decision context, and the current manual and issues register identify superseded statements. Dated proposal entries do not grant implementation approval.

## Documentation source

Markdown chapters, original screenshots, diagram definitions and the authoring scripts are under documentation. The Word and PDF are distributed alongside this archive. Python documentation tools require python-docx, Pillow and lxml; the document renderer additionally uses LibreOffice and Poppler. Source rebuilding itself requires Node and the standard-library Python maintenance scripts only.

SHA256SUMS.txt covers every archive member except itself. The source inventory and file-coverage.csv also account for reviewed files excluded from this distribution. Their historical hashes are evidence of the review baseline, not an instruction to restore excluded data.
